# Fortnite AFK Monitor

App Android (Kotlin + Jetpack Compose) que **mede o tempo** das suas sessões e **observa** se o Fortnite está aberto.

> **O que o app NÃO faz:** não automatiza partidas, não simula toques ou movimentos e não tenta burlar o sistema anti-AFK do Fortnite. Ele só lê, de forma passiva, qual app está em primeiro plano.

## Recursos

- Interface escura com detalhes azuis e roxos, pensada para telas pequenas
- Cronômetro da sessão (continua rodando com o app fechado, via serviço em primeiro plano)
- Tempo de jogo: soma o tempo em que o Fortnite esteve em primeiro plano com a tela ligada
- "Jogo hoje" e histórico de sessões (salvo no aparelho, até 200 sessões)
- Painel de status: instalado, acesso de uso, jogando / fora do jogo / parado
- Notificações personalizáveis: ao abrir o jogo, ao sair, lembrete de pausa (15 a 180 min) e botão de teste
- Botões INICIAR e PARAR (também há "Parar" na notificação)

## Requisitos

- Android 8.0 (API 26) ou superior
- Android Studio (versão recente) com JDK 17 (já vem junto)

## Gerar o APK

### Pelo Android Studio (recomendado)

1. Abra o Android Studio > **Open** e selecione a pasta `FortniteAFKMonitor`.
2. Aguarde o **Gradle Sync** terminar (baixa as dependências; precisa de internet).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Clique em **locate** na mensagem que aparecer. O arquivo fica em:
   `app/build/outputs/apk/debug/app-debug.apk`

### Pela linha de comando

Com o Gradle 8.9+ instalado, dentro da pasta do projeto:

```bash
gradle wrapper --gradle-version 8.9   # só na primeira vez
./gradlew assembleDebug               # Windows: gradlew.bat assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/app-debug.apk`.
Para uma versão otimizada de uso pessoal: `./gradlew assembleRelease`
(`app/build/outputs/apk/release/app-release.apk`, assinada com a chave de debug).

## Instalar no celular

1. Copie o `.apk` para o celular (cabo USB, Google Drive, e-mail...).
2. No celular, abra o arquivo. Se pedir, permita **"Instalar apps desconhecidos"** para o app que você usou para abrir (Arquivos, Chrome etc.).
3. Toque em **Instalar**.

Ou, com depuração USB ativada: `adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Primeiro uso

1. Abra o app e toque em **INICIAR**; aceite a permissão de notificações.
2. No painel, toque em **CONCEDER ACESSO DE USO**, escolha *Fortnite AFK Monitor* e ative a opção. Sem isso o cronômetro da sessão funciona, mas o tempo de jogo não é detectado.
3. Volte ao app. Pronto: abra o Fortnite e o status muda para **JOGANDO**.

Em alguns aparelhos (Xiaomi, Samsung, Huawei etc.) vale desativar a otimização de bateria para o app, para o sistema não encerrar o serviço.

## Observações

- O pacote do Fortnite está em `FortniteDetector.PACKAGES` (`com.epicgames.fortnite`). Se a sua instalação usar outro, adicione aqui e em `<queries>` no `AndroidManifest.xml`.
- Sessões com menos de 5 segundos não são salvas no histórico.
- Se o sistema encerrar o serviço à força, a sessão em andamento é salva no histórico.

## Estrutura

```
app/src/main/java/com/fortniteafk/monitor/
  MainActivity.kt          Activity (Compose)
  FortniteApp.kt           Application
  MonitorService.kt        Serviço: cronômetro, tempo de jogo, notificações
  FortniteDetector.kt      Leitura passiva do app em primeiro plano
  MonitorRepository.kt     Estado, histórico e configurações
  NotificationHelper.kt    Canais e notificações
  Models.kt                Modelos e formatação
  ui/Theme.kt              Cores e tema
  ui/Screens.kt            Painel, Histórico e Ajustes
```
