package com.fortniteafk.monitor

import java.util.Calendar
import java.util.Locale

/** Uma sessão de monitoramento já finalizada (guardada no histórico). */
data class SessionRecord(
    val id: Long,
    val startMillis: Long,
    val endMillis: Long,
    /** Duração total da sessão de monitoramento, em segundos. */
    val monitoredSeconds: Long,
    /** Tempo em que o Fortnite esteve em primeiro plano, em segundos. */
    val playSeconds: Long
)

/** Preferências de notificação. */
data class AppSettings(
    val notifyOnGameStart: Boolean = true,
    val notifyOnGameStop: Boolean = true,
    val reminderEnabled: Boolean = true,
    val reminderMinutes: Int = 60
)

enum class GameStatus { NOT_INSTALLED, NO_PERMISSION, STOPPED, PLAYING, OUT_OF_GAME }

data class MonitorUiState(
    val monitoring: Boolean = false,
    val sessionStartMillis: Long = 0L,
    val sessionSeconds: Long = 0L,
    val playSeconds: Long = 0L,
    val playing: Boolean = false,
    val installed: Boolean = false,
    val hasUsagePermission: Boolean = false,
    val history: List<SessionRecord> = emptyList(),
    val settings: AppSettings = AppSettings()
)

fun MonitorUiState.gameStatus(): GameStatus = when {
    !installed -> GameStatus.NOT_INSTALLED
    !hasUsagePermission -> GameStatus.NO_PERMISSION
    !monitoring -> GameStatus.STOPPED
    playing -> GameStatus.PLAYING
    else -> GameStatus.OUT_OF_GAME
}

/** Tempo de jogo acumulado hoje (sessões encerradas hoje + sessão atual). */
fun MonitorUiState.todayPlaySeconds(): Long {
    val startOfDay = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return history.filter { it.endMillis >= startOfDay }.sumOf { it.playSeconds } + playSeconds
}

fun formatHms(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}

fun formatShort(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return when {
        h > 0 -> "${h}h ${m}min"
        m > 0 -> "${m}min ${s}s"
        else -> "${s}s"
    }
}
