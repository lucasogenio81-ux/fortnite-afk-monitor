package com.fortniteafk.monitor.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.GenericShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fortniteafk.monitor.AppSettings
import com.fortniteafk.monitor.FortniteDetector
import com.fortniteafk.monitor.GameStatus
import com.fortniteafk.monitor.MonitorRepository
import com.fortniteafk.monitor.MonitorService
import com.fortniteafk.monitor.MonitorUiState
import com.fortniteafk.monitor.NotificationHelper
import com.fortniteafk.monitor.R
import com.fortniteafk.monitor.SessionRecord
import com.fortniteafk.monitor.formatHms
import com.fortniteafk.monitor.formatShort
import com.fortniteafk.monitor.gameStatus
import com.fortniteafk.monitor.todayPlaySeconds
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val CardShape = RoundedCornerShape(18.dp)

/** Paralelogramo inclinado, no estilo dos botões do jogo. */
private val SkewShape = GenericShape { size, _ ->
    val skew = size.height * 0.28f
    moveTo(skew, 0f)
    lineTo(size.width, 0f)
    lineTo(size.width - skew, size.height)
    lineTo(0f, size.height)
    close()
}

// ============================================================
// Raiz do app: abas + permissões
// ============================================================

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val state by MonitorRepository.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    // Ao voltar das configurações do sistema, reavalia permissões.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        MonitorRepository.refreshEnvironment()
    }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Inicia o monitoramento mesmo se a permissão de notificação for negada.
        startMonitoring(context)
    }

    val onStart: () -> Unit = {
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startMonitoring(context)
        }
    }
    val onStop: () -> Unit = { stopMonitoring(context) }

    Scaffold(
        containerColor = FN.Bg,
        bottomBar = { BottomBar(selected = tab, onSelect = { tab = it }) }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .background(FN.Background)
                .padding(padding)
        ) {
            when (tab) {
                0 -> DashboardScreen(state, onStart, onStop)
                1 -> HistoryScreen(state)
                else -> SettingsScreen(state)
            }
        }
    }
}

private fun startMonitoring(context: Context) {
    val intent = Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_START)
    ContextCompat.startForegroundService(context, intent)
}

private fun stopMonitoring(context: Context) {
    context.startService(
        Intent(context, MonitorService::class.java).setAction(MonitorService.ACTION_STOP)
    )
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        "PAINEL" to Icons.Default.Home,
        "HISTÓRICO" to Icons.Default.DateRange,
        "AJUSTES" to Icons.Default.Settings
    )
    NavigationBar(containerColor = FN.Surface) {
        items.forEachIndexed { index, (label, icon) ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = FN.Bg,
                    selectedTextColor = FN.Blue,
                    indicatorColor = FN.Blue,
                    unselectedIconColor = FN.Muted,
                    unselectedTextColor = FN.Muted
                )
            )
        }
    }
}

// ============================================================
// Painel
// ============================================================

@Composable
private fun DashboardScreen(state: MonitorUiState, onStart: () -> Unit, onStop: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Header()
        TimerCard(state)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatTile("JOGO NA SESSÃO", formatShort(state.playSeconds), Modifier.weight(1f))
            StatTile("JOGO HOJE", formatShort(state.todayPlaySeconds()), Modifier.weight(1f))
        }
        StatusPanel(state)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GradientButton(
                text = "INICIAR",
                enabled = !state.monitoring,
                brush = FN.Gradient,
                modifier = Modifier.weight(1f),
                onClick = onStart,
                icon = { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
            )
            GradientButton(
                text = "PARAR",
                enabled = state.monitoring,
                brush = FN.StopGradient,
                modifier = Modifier.weight(1f),
                onClick = onStop,
                icon = {
                    Box(
                        Modifier
                            .size(14.dp)
                            .background(Color.White, RoundedCornerShape(3.dp))
                    )
                }
            )
        }
        Text(
            text = if (state.monitoring) "Monitorando em segundo plano. Você pode fechar o app."
            else "Toque em INICIAR para começar a contar a sessão.",
            color = FN.Muted,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun Header() {
    Column {
        Text(
            "FORTNITE",
            style = TextStyle(
                brush = FN.TextGradient,
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic,
                letterSpacing = 2.sp
            )
        )
        Text(
            "AFK MONITOR",
            color = FN.Text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = 6.sp
        )
    }
}

@Composable
private fun TimerCard(state: MonitorUiState) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(FN.Surface)
            .border(1.5.dp, FN.Gradient, CardShape)
            .padding(vertical = 22.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "TEMPO DA SESSÃO",
            color = FN.Muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            formatHms(state.sessionSeconds),
            maxLines = 1,
            style = TextStyle(
                brush = FN.TextGradient,
                fontSize = 46.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic,
                fontFamily = FontFamily.Monospace
            )
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(CardShape)
            .background(FN.Surface)
            .padding(14.dp)
    ) {
        Text(
            label,
            color = FN.Muted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            color = FN.Text,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun StatusPanel(state: MonitorUiState) {
    val context = LocalContext.current
    val status = state.gameStatus()

    val (label, color, description) = when (status) {
        GameStatus.NOT_INSTALLED -> Triple(
            "NÃO INSTALADO", FN.Red, "O Fortnite não foi encontrado neste aparelho."
        )
        GameStatus.NO_PERMISSION -> Triple(
            "SEM PERMISSÃO", FN.Amber,
            "Conceda o acesso de uso para o app detectar quando o Fortnite está aberto."
        )
        GameStatus.STOPPED -> Triple(
            "PARADO", FN.Muted, "Inicie o monitoramento para acompanhar o jogo."
        )
        GameStatus.PLAYING -> Triple(
            "JOGANDO", FN.Green, "O Fortnite está em primeiro plano. Tempo de jogo contando."
        )
        GameStatus.OUT_OF_GAME -> Triple(
            "FORA DO JOGO", FN.Blue, "O Fortnite não está em primeiro plano agora."
        )
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(FN.Surface)
            .padding(16.dp)
    ) {
        Text(
            "STATUS DO FORTNITE",
            color = FN.Muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(color, pulse = status == GameStatus.PLAYING)
            Spacer(Modifier.width(10.dp))
            Text(
                label,
                color = color,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(description, color = FN.Text.copy(alpha = 0.8f), fontSize = 13.sp)

        Spacer(Modifier.height(12.dp))
        InfoRow("Fortnite instalado", state.installed)
        InfoRow("Acesso de uso concedido", state.hasUsagePermission)
        InfoRow("Monitoramento ativo", state.monitoring)

        if (!state.hasUsagePermission) {
            Spacer(Modifier.height(12.dp))
            SmallButton("CONCEDER ACESSO DE USO") {
                context.startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        val launch = FortniteDetector.installedPackage(context)
            ?.let { context.packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) {
            Spacer(Modifier.height(8.dp))
            SmallButton("ABRIR FORTNITE") { context.startActivity(launch) }
        }
    }
}

@Composable
private fun StatusDot(color: Color, pulse: Boolean) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val a by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "alpha"
    )
    Box(
        Modifier
            .size(14.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = if (pulse) a else 1f))
    )
}

@Composable
private fun InfoRow(label: String, ok: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = FN.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(
            if (ok) "SIM" else "NÃO",
            color = if (ok) FN.Green else FN.Muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun GradientButton(
    text: String,
    enabled: Boolean,
    brush: Brush,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Row(
        modifier
            .height(56.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(SkewShape)
            .background(if (enabled) brush else SolidColor(FN.SurfaceHi))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(8.dp))
        Text(
            text,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic,
            letterSpacing = 1.sp
        )
    }
}

@Composable
private fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(FN.SurfaceHi)
            .border(1.dp, FN.Purple.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = FN.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

// ============================================================
// Histórico
// ============================================================

@Composable
private fun HistoryScreen(state: MonitorUiState) {
    var confirmClear by remember { mutableStateOf(false) }
    val totalPlay = state.history.sumOf { it.playSeconds }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "HISTÓRICO",
                style = TextStyle(
                    brush = FN.TextGradient,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    fontStyle = FontStyle.Italic,
                    letterSpacing = 2.sp
                )
            )
            Text(
                "${state.history.size} sessões · ${formatShort(totalPlay)} de jogo no total",
                color = FN.Muted,
                fontSize = 13.sp
            )
        }

        if (state.history.isEmpty()) {
            item {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(CardShape)
                        .background(FN.Surface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Nenhuma sessão ainda.\nInicie o monitoramento para registrar a primeira.",
                        color = FN.Muted,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            items(state.history, key = { it.id }) { SessionCard(it) }
            item {
                SmallButton("LIMPAR HISTÓRICO") { confirmClear = true }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = FN.Surface,
            title = { Text("Limpar histórico?", color = FN.Text, fontWeight = FontWeight.Bold) },
            text = {
                Text("Todas as sessões salvas serão apagadas.", color = FN.Muted)
            },
            confirmButton = {
                TextButton(onClick = {
                    MonitorRepository.clearHistory()
                    confirmClear = false
                }) { Text("APAGAR", color = FN.Red, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) {
                    Text("CANCELAR", color = FN.Blue, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun SessionCard(record: SessionRecord) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy · HH:mm", Locale("pt", "BR")) }
    val percent = if (record.monitoredSeconds > 0)
        (record.playSeconds * 100 / record.monitoredSeconds).toInt() else 0

    Column(
        Modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(FN.Surface)
            .padding(16.dp)
    ) {
        Text(
            dateFormat.format(Date(record.startMillis)),
            color = FN.Blue,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("SESSÃO", color = FN.Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Text(
                    formatHms(record.monitoredSeconds),
                    color = FN.Text,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column(Modifier.weight(1f)) {
                Text("JOGO", color = FN.Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Text(
                    formatHms(record.playSeconds),
                    color = FN.Purple,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape)
                .background(FN.SurfaceHi)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(percent.coerceIn(0, 100) / 100f)
                    .height(6.dp)
                    .background(FN.Gradient)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text("$percent% da sessão com o Fortnite aberto", color = FN.Muted, fontSize = 11.sp)
    }
}

// ============================================================
// Ajustes / Notificações
// ============================================================

@Composable
private fun SettingsScreen(state: MonitorUiState) {
    val context = LocalContext.current
    val settings = state.settings
    var sliderValue by remember(settings.reminderMinutes) {
        mutableFloatStateOf(settings.reminderMinutes.toFloat())
    }

    fun save(new: AppSettings) = MonitorRepository.updateSettings(new)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "NOTIFICAÇÕES",
            style = TextStyle(
                brush = FN.TextGradient,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Italic,
                letterSpacing = 2.sp
            )
        )

        Column(
            Modifier
                .fillMaxWidth()
                .clip(CardShape)
                .background(FN.Surface)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SettingSwitch(
                "Aviso ao abrir o Fortnite",
                "Notifica quando o jogo entra em primeiro plano.",
                settings.notifyOnGameStart
            ) { save(settings.copy(notifyOnGameStart = it)) }

            SettingSwitch(
                "Aviso ao sair do Fortnite",
                "Mostra o tempo de jogo da sessão ao sair.",
                settings.notifyOnGameStop
            ) { save(settings.copy(notifyOnGameStop = it)) }

            SettingSwitch(
                "Lembrete de pausa",
                "Avisa a cada intervalo de tempo de jogo.",
                settings.reminderEnabled
            ) { save(settings.copy(reminderEnabled = it)) }

            if (settings.reminderEnabled) {
                Text(
                    "Intervalo: ${sliderValue.roundToInt()} min",
                    color = FN.Text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Slider(
                    value = sliderValue,
                    onValueChange = { sliderValue = it },
                    onValueChangeFinished = {
                        save(settings.copy(reminderMinutes = sliderValue.roundToInt()))
                    },
                    valueRange = 15f..180f,
                    steps = 10,
                    colors = SliderDefaults.colors(
                        thumbColor = FN.Blue,
                        activeTrackColor = FN.Purple,
                        inactiveTrackColor = FN.SurfaceHi,
                        activeTickColor = FN.Bg,
                        inactiveTickColor = FN.Muted
                    )
                )
            }
        }

        GradientButton(
            text = "TESTAR NOTIFICAÇÃO",
            enabled = true,
            brush = FN.Gradient,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                NotificationHelper.alert(
                    context,
                    context.getString(R.string.app_name),
                    context.getString(R.string.notif_test_text)
                )
            },
            icon = {}
        )

        Column(
            Modifier
                .fillMaxWidth()
                .clip(CardShape)
                .background(FN.Surface)
                .padding(16.dp)
        ) {
            Text(
                "SOBRE",
                color = FN.Muted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Este app apenas mede tempo e observa se o Fortnite está aberto. " +
                    "Ele não automatiza partidas, não simula toques ou movimentos e " +
                    "não interfere no sistema anti-AFK do jogo.",
                color = FN.Text.copy(alpha = 0.8f),
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = FN.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = FN.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = FN.Purple,
                uncheckedThumbColor = FN.Muted,
                uncheckedTrackColor = FN.SurfaceHi
            )
        )
    }
}
