package com.fortniteafk.monitor

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process

/**
 * Apenas LÊ o estado do sistema para saber se o Fortnite está em primeiro plano.
 * Não envia toques, não controla o jogo e não interage com ele de nenhuma forma.
 */
class FortniteDetector(private val context: Context) {

    companion object {
        /** Pacote(s) do Fortnite. Se o seu aparelho usar outro pacote, adicione aqui. */
        val PACKAGES = listOf("com.epicgames.fortnite")

        @Suppress("DEPRECATION")
        fun isInstalled(context: Context): Boolean = installedPackage(context) != null

        @Suppress("DEPRECATION")
        fun installedPackage(context: Context): String? = PACKAGES.firstOrNull { pkg ->
            try {
                context.packageManager.getPackageInfo(pkg, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
        }

        @Suppress("DEPRECATION")
        fun hasUsageAccess(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            } else {
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            }
            return if (mode == AppOpsManager.MODE_DEFAULT) {
                context.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) ==
                    PackageManager.PERMISSION_GRANTED
            } else {
                mode == AppOpsManager.MODE_ALLOWED
            }
        }
    }

    private var lastQuery = 0L
    private var fortniteInForeground = false

    fun reset() {
        lastQuery = 0L
        fortniteInForeground = false
    }

    /** Retorna true se o Fortnite está em primeiro plano neste momento. */
    fun poll(): Boolean {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 6L * 60 * 60 * 1000 else lastQuery
        val events = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val isFortnite = e.packageName in PACKAGES
            when (e.eventType) {
                // 1 = ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
                UsageEvents.Event.ACTIVITY_RESUMED ->
                    fortniteInForeground = isFortnite
                // 2 = ACTIVITY_PAUSED, 23 = ACTIVITY_STOPPED
                UsageEvents.Event.ACTIVITY_PAUSED,
                UsageEvents.Event.ACTIVITY_STOPPED ->
                    if (isFortnite) fortniteInForeground = false
            }
        }
        lastQuery = now
        return fortniteInForeground
    }
}
