package com.fortniteafk.monitor

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

/** Guarda o estado atual do app e persiste histórico e preferências. */
object MonitorRepository {

    private const val PREFS = "fortnite_afk_monitor"
    private const val KEY_HISTORY = "history"
    private const val MAX_HISTORY = 200

    private lateinit var app: Context
    private val _state = MutableStateFlow(MonitorUiState())
    val state: StateFlow<MonitorUiState> = _state.asStateFlow()

    private val prefs get() = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun init(context: Context) {
        if (::app.isInitialized) return
        app = context.applicationContext
        _state.value = _state.value.copy(history = loadHistory(), settings = loadSettings())
        refreshEnvironment()
    }

    // ---------- Ambiente (instalado? permissão?) ----------

    fun refreshEnvironment() {
        val installed = FortniteDetector.isInstalled(app)
        val access = FortniteDetector.hasUsageAccess(app)
        _state.update { it.copy(installed = installed, hasUsagePermission = access) }
    }

    // ---------- Sessão ----------

    fun beginSession(startMillis: Long) {
        _state.update {
            it.copy(
                monitoring = true,
                sessionStartMillis = startMillis,
                sessionSeconds = 0L,
                playSeconds = 0L,
                playing = false
            )
        }
    }

    fun updateTick(sessionSeconds: Long, playSeconds: Long, playing: Boolean) {
        _state.update {
            if (!it.monitoring) it
            else it.copy(sessionSeconds = sessionSeconds, playSeconds = playSeconds, playing = playing)
        }
    }

    /** Encerra a sessão atual e grava no histórico (ignora sessões com menos de 5 s). */
    fun endSession() {
        val s = _state.value
        if (!s.monitoring) return
        val end = System.currentTimeMillis()
        var history = s.history
        if (s.sessionSeconds >= 5) {
            val record = SessionRecord(
                id = end,
                startMillis = s.sessionStartMillis,
                endMillis = end,
                monitoredSeconds = s.sessionSeconds,
                playSeconds = s.playSeconds
            )
            history = (listOf(record) + history).take(MAX_HISTORY)
            saveHistory(history)
        }
        _state.update {
            it.copy(
                monitoring = false,
                sessionSeconds = 0L,
                playSeconds = 0L,
                playing = false,
                history = history
            )
        }
    }

    // ---------- Histórico ----------

    fun clearHistory() {
        saveHistory(emptyList())
        _state.update { it.copy(history = emptyList()) }
    }

    private fun loadHistory(): List<SessionRecord> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SessionRecord(
                    id = o.getLong("id"),
                    startMillis = o.getLong("start"),
                    endMillis = o.getLong("end"),
                    monitoredSeconds = o.getLong("monitored"),
                    playSeconds = o.getLong("play")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveHistory(list: List<SessionRecord>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("start", it.startMillis)
                    .put("end", it.endMillis)
                    .put("monitored", it.monitoredSeconds)
                    .put("play", it.playSeconds)
            )
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    // ---------- Configurações ----------

    fun updateSettings(settings: AppSettings) {
        prefs.edit()
            .putBoolean("notify_start", settings.notifyOnGameStart)
            .putBoolean("notify_stop", settings.notifyOnGameStop)
            .putBoolean("reminder_enabled", settings.reminderEnabled)
            .putInt("reminder_minutes", settings.reminderMinutes)
            .apply()
        _state.update { it.copy(settings = settings) }
    }

    private fun loadSettings(): AppSettings {
        val p = prefs
        val d = AppSettings()
        return AppSettings(
            notifyOnGameStart = p.getBoolean("notify_start", d.notifyOnGameStart),
            notifyOnGameStop = p.getBoolean("notify_stop", d.notifyOnGameStop),
            reminderEnabled = p.getBoolean("reminder_enabled", d.reminderEnabled),
            reminderMinutes = p.getInt("reminder_minutes", d.reminderMinutes)
        )
    }
}
