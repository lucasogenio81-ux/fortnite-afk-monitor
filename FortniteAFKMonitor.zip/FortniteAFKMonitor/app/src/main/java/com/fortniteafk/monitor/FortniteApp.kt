package com.fortniteafk.monitor

import android.app.Application

class FortniteApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MonitorRepository.init(this)
    }
}
