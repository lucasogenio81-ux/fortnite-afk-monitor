package com.fortniteafk.monitor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Paleta escura com detalhes azuis e roxos. */
object FN {
    val Bg = Color(0xFF080A14)
    val Surface = Color(0xFF12152B)
    val SurfaceHi = Color(0xFF1B1F3D)

    val Blue = Color(0xFF2BB8FF)
    val BlueDeep = Color(0xFF2F6BFF)
    val Purple = Color(0xFF9A5CFF)
    val PurpleDeep = Color(0xFF6A2CFF)

    val Text = Color(0xFFF2F4FF)
    val Muted = Color(0xFF8A90B8)

    val Green = Color(0xFF3DFFA2)
    val Red = Color(0xFFFF4D6D)
    val Amber = Color(0xFFFFC857)

    val Gradient = Brush.horizontalGradient(listOf(BlueDeep, PurpleDeep))
    val TextGradient = Brush.horizontalGradient(listOf(Blue, Purple))
    val StopGradient = Brush.horizontalGradient(listOf(Red, Color(0xFFB02AFF)))
    val Background = Brush.verticalGradient(listOf(Color(0xFF0E1130), Bg))
}

@Composable
fun FortniteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FN.Blue,
            onPrimary = FN.Bg,
            secondary = FN.Purple,
            background = FN.Bg,
            onBackground = FN.Text,
            surface = FN.Surface,
            onSurface = FN.Text,
            surfaceVariant = FN.SurfaceHi,
            onSurfaceVariant = FN.Muted
        ),
        content = content
    )
}
