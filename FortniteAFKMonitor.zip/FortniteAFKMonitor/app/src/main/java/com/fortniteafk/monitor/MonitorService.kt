package com.fortniteafk.monitor

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Serviço em primeiro plano que:
 *  - conta o tempo da sessão;
 *  - lê (somente leitura) se o Fortnite está em primeiro plano para somar o tempo de jogo;
 *  - dispara as notificações configuradas.
 *
 * Ele NÃO interage com o jogo: não simula toques, não move o personagem e
 * não tenta evitar nenhum sistema anti-AFK.
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_START = "com.fortniteafk.monitor.START"
        const val ACTION_STOP = "com.fortniteafk.monitor.STOP"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loopJob: Job? = null
    private lateinit var detector: FortniteDetector
    private var startWall = 0L

    override fun onCreate() {
        super.onCreate()
        MonitorRepository.init(this)
        detector = FortniteDetector(applicationContext)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMonitoring()
            return START_NOT_STICKY
        }
        if (loopJob?.isActive != true) startMonitoring()
        return START_NOT_STICKY
    }

    private fun startMonitoring() {
        NotificationHelper.createChannels(this)
        startWall = System.currentTimeMillis()
        goForeground(
            NotificationHelper.buildOngoing(this, startWall, getString(R.string.notif_waiting))
        )
        MonitorRepository.beginSession(startWall)
        detector.reset()
        loopJob = scope.launch { monitorLoop() }
    }

    private fun stopMonitoring() {
        loopJob?.cancel()
        loopJob = null
        MonitorRepository.endSession()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NotificationHelper.ID_ONGOING, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NotificationHelper.ID_ONGOING, n)
        }
    }

    private suspend fun CoroutineScope.monitorLoop() {
        val power = getSystemService(POWER_SERVICE) as PowerManager
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        val startElapsed = SystemClock.elapsedRealtime()
        var lastElapsed = startElapsed
        var playMillis = 0L
        var wasPlaying = false
        var lastInterval = -1
        var lastBucket = 0L
        var lastText = getString(R.string.notif_waiting)
        var tick = 0

        while (isActive) {
            delay(1000)
            val now = SystemClock.elapsedRealtime()
            val delta = now - lastElapsed
            lastElapsed = now

            if (tick % 5 == 0) MonitorRepository.refreshEnvironment()
            tick++

            val state = MonitorRepository.state.value
            val settings = state.settings
            val hasAccess = state.hasUsagePermission

            // Somente leitura: pergunta ao sistema qual app está em primeiro plano.
            val fortniteForeground = if (hasAccess) {
                withContext(Dispatchers.Default) { detector.poll() }
            } else false
            val playing = fortniteForeground && power.isInteractive
            if (playing) playMillis += delta

            // Notificações de início/fim de jogo
            if (playing && !wasPlaying && settings.notifyOnGameStart) {
                NotificationHelper.alert(
                    this@MonitorService,
                    getString(R.string.notif_started_title),
                    getString(R.string.notif_started_text)
                )
            }
            if (!playing && wasPlaying && settings.notifyOnGameStop) {
                NotificationHelper.alert(
                    this@MonitorService,
                    getString(R.string.notif_stopped_title),
                    getString(R.string.notif_stopped_text, formatShort(playMillis / 1000))
                )
            }
            wasPlaying = playing

            // Lembrete de pausa a cada X minutos de jogo
            if (settings.reminderEnabled) {
                val intervalMs = settings.reminderMinutes * 60_000L
                if (settings.reminderMinutes != lastInterval) {
                    lastInterval = settings.reminderMinutes
                    lastBucket = playMillis / intervalMs
                }
                val bucket = playMillis / intervalMs
                if (bucket > lastBucket) {
                    lastBucket = bucket
                    NotificationHelper.alert(
                        this@MonitorService,
                        getString(R.string.notif_reminder_title),
                        getString(
                            R.string.notif_reminder_text,
                            (bucket * settings.reminderMinutes).toInt()
                        )
                    )
                }
            } else {
                lastInterval = -1
            }

            MonitorRepository.updateTick((now - startElapsed) / 1000, playMillis / 1000, playing)

            // Atualiza o texto da notificação fixa só quando muda o status
            val text = when {
                !hasAccess -> getString(R.string.notif_no_access)
                playing -> getString(R.string.notif_playing)
                else -> getString(R.string.notif_out)
            }
            if (text != lastText) {
                lastText = text
                nm.notify(
                    NotificationHelper.ID_ONGOING,
                    NotificationHelper.buildOngoing(this@MonitorService, startWall, text)
                )
            }
        }
    }

    override fun onDestroy() {
        loopJob?.cancel()
        // Se o sistema encerrar o serviço, salva a sessão em andamento.
        MonitorRepository.endSession()
        scope.cancel()
        super.onDestroy()
    }
}
